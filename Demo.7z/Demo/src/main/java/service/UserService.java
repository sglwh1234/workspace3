package service;

import entiy.User;

public interface UserService {
	public void addUser(User user);
}
