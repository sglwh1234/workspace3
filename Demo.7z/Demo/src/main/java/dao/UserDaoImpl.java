package dao;



import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import dao.UserDao;
import entiy.User;

@Repository("userDao")
public class UserDaoImpl implements UserDao {
	
	@Resource(name="sessionFactory")
	public SessionFactory sessionFactory;
	
	public Session getSession(){
		return sessionFactory.getCurrentSession();
	}
	
	@Transactional
	public void addUser(User user) {
		// TODO Auto-generated method stub
		
		getSession().save(user);
		
	}

	

}
