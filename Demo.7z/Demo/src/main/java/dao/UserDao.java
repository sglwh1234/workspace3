package dao;



import entiy.User;

public interface UserDao {
	public void addUser(User user);
}
