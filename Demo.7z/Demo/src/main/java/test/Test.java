package test;

import javax.annotation.Resource;

import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import entiy.User;
import service.UserService;

import org.springframework.test.context.ContextConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
//加载spring配置文件
@ContextConfiguration(locations = {"classpath*:applicationContext.xml"})
@Transactional
public class Test{
	
	@Resource
	private UserService  userService;
	
	@org.junit.Test
	public void testAddUser(){
		User user=new User();
		user.setId(111);
		user.setUserName("kdkd");
		userService.addUser(user);
		
	}
}