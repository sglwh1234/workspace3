package entiy;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="user")
public class User implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5638028816591989902L;
		//定义属性
		private int id;
		private String userName;
		private String password;
		private String email;
		

		//定义构造方法方便初始化值
		public User(){}
		  
		
		public User(int id, String userName, String password, String email) {
			super();
			this.id = id;
			this.userName = userName;
			this.password = password;
			this.email = email;
		}


		//GETTER/SETTER
		@Id
		@Column(name = "id", unique = true, nullable = false, length = 36)
		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}
		
		public String getUserName() {
			return userName;
		}
	
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		
	
		
}
