package controller;

//import java.util.Map;

import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	
	//Model 对象来赋值和传递参数
	/*@RequestMapping(value="/login")
	public String login(String username, Model model){
		System.out.println("this is a login page"+username);
		model.addAttribute("username",username );
		return "login";*/
	
	
	//用ModelAndView对象来传递参数和赋值
	
	@RequestMapping(value="/login")
	public ModelAndView login(String userName){
		System.out.println("this is a login page"+userName);
		ModelAndView mvView=new ModelAndView();
		mvView.setViewName("login");
		mvView.addObject("username", userName);
		return mvView;
	
	//用键值对来传递参数和接收
	/*@RequestMapping(value="/login")
	public String hello(String username, Map<String,Object> model){
		model.put("username", username);
		return "login";
	*/
	
	
	}
}
